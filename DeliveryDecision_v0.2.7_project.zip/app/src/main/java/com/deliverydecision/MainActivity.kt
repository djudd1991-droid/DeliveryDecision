package com.deliverydecision

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())

    private val green = Color.rgb(180,255,0)
    private val brightGreen = Color.rgb(195,255,20)
    private val red = Color.rgb(255,55,45)
    private val dim = Color.rgb(195,205,195)
    private val cardFill = Color.argb(236,2,10,6)
    private val cardStroke = Color.rgb(118,180,35)

    private lateinit var pageHost: FrameLayout
    private lateinit var nav: LinearLayout
    private var currentTab = "Home"

    private var liveEarnings: TextView? = null
    private var liveMiles: TextView? = null
    private var liveTime: TextView? = null
    private var liveStatus: TextView? = null
    private var liveAuto: TextView? = null
    private var activeMetric: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(2,8,2)
        window.navigationBarColor = Color.rgb(2,8,2)
        buildShell()
        showTab("Home")
        ui.post(refresh)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private val refresh = object : Runnable {
        override fun run() {
            if (currentTab == "Home") updateHomeLive()
            ui.postDelayed(this, 1000L)
        }
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(1,5,1))
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(0, bars.top, 0, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            }
            insets
        }

        pageHost = FrameLayout(this)
        root.addView(pageHost, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(5))
            background = rounded(Color.rgb(2,8,4), cardStroke, 1, 13f)
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
    }

    private fun showTab(tab: String) {
        currentTab = tab
        pageHost.removeAllViews()
        pageHost.addView(pageBackground())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(5), dp(10), dp(14))
        }
        scroll.addView(content)
        pageHost.addView(scroll, FrameLayout.LayoutParams(-1,-1))

        when (tab) {
            "Home" -> buildHome(content)
            "History" -> buildHistory(content)
            "Reports" -> buildReports(content)
            "Accounts" -> buildAccounts(content)
            "Settings" -> buildSettings(content)
            "Taxes" -> buildTaxes(content)
        }
        rebuildNav()
    }

    private fun pageBackground(): View {
        val frame = FrameLayout(this)
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.money_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        frame.addView(bg, FrameLayout.LayoutParams(-1,-1))
        frame.addView(View(this).apply {
            setBackgroundColor(Color.argb(22,0,0,0))
        }, FrameLayout.LayoutParams(-1,-1))
        return frame
    }

    // Reference mockup uses the DD/TAKE emblem as the persistent page header.
    private fun buildHeader(parent: LinearLayout) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(7))
        }
        val halo = FrameLayout(this).apply {
            background = rounded(Color.argb(205,0,18,2), brightGreen, 2, 42f)
            setPadding(dp(4),dp(4),dp(4),dp(4))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, brightGreen, 1, 34f)
        }
        halo.addView(icon, FrameLayout.LayoutParams(dp(84),dp(84),Gravity.CENTER))
        wrap.addView(halo, LinearLayout.LayoutParams(dp(94),dp(94)))
        parent.addView(wrap)
    }

    private fun buildHome(p: LinearLayout) {
        buildHeader(p)

        val status = card()
        val sr = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        liveStatus = txt("",13f,green,true)
        sr.addView(liveStatus, LinearLayout.LayoutParams(0,-2,1f))
        liveTime = txt("00:00:00",17f,green,true)
        sr.addView(liveTime)
        status.addView(sr)
        p.addView(status)
        gap(p,8)

        val summary = card()
        summary.addView(title("TODAY'S SUMMARY"))
        summary.addView(div())

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val e = mockMetric("EARNINGS", "$0.00", "")
        liveEarnings = e.second
        val m = mockMetric("MILES", "0.0", "${f1(prefs.getFloat("mpg",20f).toDouble())} mpg")
        liveMiles = m.second
        val a = mockMetric("ACTIVE TIME", "00:00", "of 00:00")
        activeMetric = a.second
        metrics.addView(e.first, LinearLayout.LayoutParams(0,-2,1f))
        metrics.addView(m.first, LinearLayout.LayoutParams(0,-2,1f))
        metrics.addView(a.first, LinearLayout.LayoutParams(0,-2,1f))
        summary.addView(metrics)

        val dashRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dashBtn = neonButton(if (prefs.getBoolean("dash_active",false)) "END DASH" else "START DASH")
        dashBtn.setOnClickListener {
            if (prefs.getBoolean("dash_active",false)) startService(Intent(this,MileageService::class.java).setAction("STOP"))
            else startDash()
        }
        dashRow.addView(dashBtn, LinearLayout.LayoutParams(0,dp(48),1f).apply { marginEnd = dp(7) })
        val stop = outlineButton("■", green)
        stop.setOnClickListener { startService(Intent(this,MileageService::class.java).setAction("STOP")) }
        dashRow.addView(stop, LinearLayout.LayoutParams(dp(54),dp(48)))
        summary.addView(dashRow, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(8) })
        p.addView(summary)
        gap(p,8)

        val apps = card()
        val appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dd = driverLaunch("DOORDASH","OPEN", red)
        dd.setOnClickListener { launchDriverApp(listOf("com.doordash.driverapp"),"DoorDash") }
        val ue = driverLaunch("UBER DRIVER","OPEN", green)
        ue.setOnClickListener { launchDriverApp(listOf("com.ubercab.driver","com.ubercab"),"Uber Driver") }
        appRow.addView(dd, LinearLayout.LayoutParams(0,dp(54),1f).apply { marginEnd=dp(5) })
        appRow.addView(ue, LinearLayout.LayoutParams(0,dp(54),1f).apply { marginStart=dp(5) })
        apps.addView(appRow)
        p.addView(apps)
        gap(p,8)

        val offer = card()
        val or = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val ot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ot.addView(title("OFFER READER"))
        ot.addView(txt("Analyze offers and get take / pass recommendations.",11f,dim,false))
        or.addView(ot, LinearLayout.LayoutParams(0,-2,1f))
        val sw = Switch(this).apply {
            isChecked = isAccessibilityEnabled()
            buttonTintList = null
            setOnCheckedChangeListener { _, checked ->
                if (checked != isAccessibilityEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        or.addView(sw)
        offer.addView(or)
        offer.addView(div())
        val rules = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r1 = tinyRule("◷","Min $/mile","$${f2(prefs.getFloat("min_dpm",1.5f).toDouble())}")
        val r2 = tinyRule("⌂","Preferred $/mile","$${f2(prefs.getFloat("preferred_dpm",2f).toDouble())}")
        val r3 = tinyRule("◷","Min $/hour","$${f2(prefs.getFloat("target_hour",25f).toDouble())}")
        rules.addView(r1,LinearLayout.LayoutParams(0,-2,1f))
        rules.addView(r2,LinearLayout.LayoutParams(0,-2,1f))
        rules.addView(r3,LinearLayout.LayoutParams(0,-2,1f))
        offer.addView(rules)
        p.addView(offer)
        gap(p,8)

        val auto = card()
        val ar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(title("AUTO-STOP TIMER"))
        left.addView(txt("No offers or movement for ${prefs.getInt("auto_stop_min",30)} minutes",11f,dim,false))
        ar.addView(left,LinearLayout.LayoutParams(0,-2,1f))
        liveAuto = txt("${prefs.getInt("auto_stop_min",30)}:00",18f,green,true)
        ar.addView(liveAuto)
        auto.addView(ar)
        p.addView(auto)

        updateHomeLive()
    }

    private fun updateHomeLive() {
        val active = prefs.getBoolean("dash_active",false)
        val start = prefs.getLong("dash_start",0L)
        val ms = if (active && start > 0) System.currentTimeMillis()-start else prefs.getLong("last_session_ms",0L)
        liveStatus?.text = if (active) "●  DASH ACTIVE" else "○  DASH NOT ACTIVE"
        liveStatus?.setTextColor(if(active) green else dim)
        liveTime?.text = formatDuration(ms)
        liveEarnings?.text = "$${f2(prefs.getFloat("today_earnings",0f).toDouble())}"
        liveMiles?.text = f1(prefs.getFloat("today_miles",0f).toDouble())
        activeMetric?.text = hhmm(ms)
        liveAuto?.text = "${prefs.getInt("auto_stop_min",30)}:00"
    }

    private fun buildHistory(p: LinearLayout) {
        buildHeader(p)

        var selected = "ALL"
        val filterCard = card()
        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val buttons = linkedMapOf<String,Button>()

        fun paint() {
            buttons.forEach { (name,b) ->
                b.background = if (name==selected) rounded(green,green,0,8f) else rounded(Color.rgb(8,11,8),Color.rgb(65,75,65),1,8f)
                b.setTextColor(if(name==selected) Color.BLACK else Color.WHITE)
                b.setTypeface(b.typeface, if(name==selected) Typeface.BOLD else Typeface.NORMAL)
            }
        }

        fun deleteLine(line: String) {
            val lines = prefs.getString("dash_history","").orEmpty().lines().filter { it.isNotBlank() }.toMutableList()
            if (lines.remove(line)) prefs.edit().putString("dash_history", if(lines.isEmpty()) "" else lines.joinToString("\n", postfix="\n")).apply()
        }

        fun showSession(line:String) {
            val x=line.split("|")
            if(x.size<3) return
            val st=x[0].toLongOrNull()?:0L
            val en=x[1].toLongOrNull()?:st
            val mi=x[2].toDoubleOrNull()?:0.0
            val platform=if(x.size>=4) x[3] else "Delivery"
            val earn=if(x.size>=5) x[4].toDoubleOrNull()?:0.0 else 0.0
            AlertDialog.Builder(this)
                .setTitle("$platform session")
                .setMessage("${SimpleDateFormat("EEE, MMM d • h:mm a",Locale.US).format(Date(st))}\n${f1(mi)} miles • ${hhmm(en-st)}\nEarnings: $${f2(earn)}")
                .setPositiveButton("CLOSE",null)
                .setNegativeButton("DELETE SESSION") { _,_ ->
                    deleteLine(line)
                    showTab("History")
                }.show()
        }

        fun render() {
            host.removeAllViews()
            val raw = prefs.getString("dash_history","").orEmpty().lines().filter { it.isNotBlank() }.takeLast(80).reversed()
            val filtered = raw.filter { line ->
                val x=line.split("|")
                val platform=if(x.size>=4) x[3].uppercase(Locale.US) else "UNKNOWN"
                selected=="ALL" || (selected=="DOORDASH" && platform=="DOORDASH") || (selected=="UBER EATS" && platform=="UBER EATS")
            }
            if(filtered.isEmpty()) {
                val c=card()
                c.addView(txt("No $selected sessions yet.",14f,dim,false))
                host.addView(c)
                return
            }

            val cal = Calendar.getInstance()
            val startThisWeek = Calendar.getInstance().apply {
                firstDayOfWeek=Calendar.SUNDAY
                set(Calendar.DAY_OF_WEEK,Calendar.SUNDAY)
                set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
            }.timeInMillis
            var addedThis=false
            var addedLast=false

            filtered.forEach { line ->
                val x=line.split("|")
                if(x.size<3) return@forEach
                val st=x[0].toLongOrNull()?:0L
                val en=x[1].toLongOrNull()?:st
                val mi=x[2].toDoubleOrNull()?:0.0
                val platform=if(x.size>=4) x[3] else "Delivery"
                val earn=if(x.size>=5) x[4].toDoubleOrNull()?:0.0 else 0.0

                if(st>=startThisWeek && !addedThis) {
                    host.addView(sectionLabel("THIS WEEK"))
                    addedThis=true
                } else if(st<startThisWeek && !addedLast) {
                    host.addView(sectionLabel("LAST WEEK"))
                    addedLast=true
                }

                val c = card()
                val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
                val logo=txt(if(platform.equals("DoorDash",true)) "D" else "Uber\nEats",12f,if(platform.equals("DoorDash",true)) red else Color.rgb(80,255,170),true).apply {
                    gravity=Gravity.CENTER
                }
                row.addView(logo,LinearLayout.LayoutParams(dp(42),dp(42)))
                val center=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
                center.addView(txt(SimpleDateFormat("EEE, MMM d",Locale.US).format(Date(st)),14f,Color.WHITE,true))
                center.addView(txt("${SimpleDateFormat("h:mm a",Locale.US).format(Date(st))} - ${SimpleDateFormat("h:mm a",Locale.US).format(Date(en))}",11f,Color.WHITE,false))
                center.addView(txt("${f1(mi)} mi  •  ${hhmm(en-st)} dash",10.5f,dim,false))
                row.addView(center,LinearLayout.LayoutParams(0,-2,1f))
                row.addView(txt(if(earn>0) "$${f2(earn)}" else "${f1(mi)} mi",14f,green,true))
                row.addView(txt("  ›",23f,Color.WHITE,false))
                c.addView(row)
                c.setOnClickListener { showSession(line) }
                c.setOnLongClickListener {
                    AlertDialog.Builder(this).setTitle("Delete this session?")
                        .setMessage("This removes it from History and Reports.")
                        .setPositiveButton("DELETE"){_,_->deleteLine(line);showTab("History")}
                        .setNegativeButton("CANCEL",null).show()
                    true
                }
                host.addView(c)
                gap(host,7)
            }
        }

        listOf("ALL","DOORDASH","UBER EATS").forEachIndexed { i,name ->
            val b=darkButton(name)
            b.setOnClickListener { selected=name; paint(); render() }
            buttons[name]=b
            filterRow.addView(b,LinearLayout.LayoutParams(0,dp(42),1f).apply { if(i>0) marginStart=dp(5) })
        }
        filterCard.addView(filterRow)
        p.addView(filterCard)
        gap(p,8)
        p.addView(host)
        paint()
        render()
    }

    private fun buildReports(p: LinearLayout) {
        buildHeader(p)

        var selected="WEEK"
        val buttons=linkedMapOf<String,Button>()
        val periodCard=card()
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val host=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }

        fun paint() {
            buttons.forEach { (name,b) ->
                b.background=if(name==selected) rounded(green,green,0,8f) else rounded(Color.rgb(8,11,8),Color.rgb(65,75,65),1,8f)
                b.setTextColor(if(name==selected) Color.BLACK else Color.WHITE)
            }
        }

        fun periodStart(name:String):Long {
            val c=Calendar.getInstance()
            when(name) {
                "DAY" -> { c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0) }
                "WEEK" -> { c.firstDayOfWeek=Calendar.SUNDAY;c.set(Calendar.DAY_OF_WEEK,Calendar.SUNDAY);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0) }
                "MONTH" -> { c.set(Calendar.DAY_OF_MONTH,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0) }
                "YEAR" -> { c.set(Calendar.DAY_OF_YEAR,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0) }
            }
            return c.timeInMillis
        }

        fun render() {
            host.removeAllViews()
            val start=periodStart(selected)
            val history=prefs.getString("dash_history","").orEmpty().lines().filter{it.isNotBlank()}
            var miles=0.0
            var ms=0L
            var earnings=0.0
            var deliveries=0
            history.forEach { line ->
                val x=line.split("|")
                if(x.size>=3) {
                    val st=x[0].toLongOrNull()?:0L
                    val en=x[1].toLongOrNull()?:st
                    if(en>=start) {
                        miles += x[2].toDoubleOrNull()?:0.0
                        ms += (en-st).coerceAtLeast(0L)
                        if(x.size>=5) earnings += x[4].toDoubleOrNull()?:0.0
                        if(x.size>=6) deliveries += x[5].toIntOrNull()?:0
                    }
                }
            }
            if(selected=="DAY") {
                miles=max(miles,prefs.getFloat("today_miles",0f).toDouble())
                earnings=max(earnings,prefs.getFloat("today_earnings",0f).toDouble())
            } else if(selected=="WEEK") miles=max(miles,prefs.getFloat("week_miles",0f).toDouble())
            else if(selected=="MONTH") miles=max(miles,prefs.getFloat("month_miles",0f).toDouble())

            val hours=ms/3600000.0
            val dpm=if(miles>0) earnings/miles else 0.0
            val dph=if(hours>0) earnings/hours else 0.0

            val dateCard=card()
            val dr=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
            dr.addView(txt("‹",28f,Color.WHITE,false))
            val label=when(selected) {
                "DAY" -> SimpleDateFormat("MMM d, yyyy",Locale.US).format(Date())
                "WEEK" -> "THIS WEEK"
                "MONTH" -> SimpleDateFormat("MMMM yyyy",Locale.US).format(Date()).uppercase(Locale.US)
                else -> SimpleDateFormat("yyyy",Locale.US).format(Date())
            }
            dr.addView(txt(label,15f,Color.WHITE,true).apply { gravity=Gravity.CENTER },LinearLayout.LayoutParams(0,-2,1f))
            dr.addView(txt("›",28f,Color.WHITE,false))
            dateCard.addView(dr)
            host.addView(dateCard)
            gap(host,7)

            val totals=card()
            val row1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row1.addView(statTile("EARNINGS","$${f2(earnings)}"),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginEnd=dp(4)})
            row1.addView(statTile("MILES",f1(miles)),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginStart=dp(2);marginEnd=dp(2)})
            row1.addView(statTile("HOURS",f2(hours)),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginStart=dp(4)})
            totals.addView(row1)
            val row2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row2.addView(statTile("$/MILE","$${f2(dpm)}"),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginEnd=dp(4)})
            row2.addView(statTile("$/HOUR","$${f2(dph)}"),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginStart=dp(2);marginEnd=dp(2)})
            row2.addView(statTile("DELIVERIES",deliveries.toString()),LinearLayout.LayoutParams(0,dp(82),1f).apply{marginStart=dp(4)})
            totals.addView(row2,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
            host.addView(totals)
            gap(host,7)

            val graph=card()
            graph.addView(title("EARNINGS OVER TIME"))
            graph.addView(div())
            val bars=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.BOTTOM }
            val dayFmt=SimpleDateFormat("yyyy-MM-dd",Locale.US)
            val labelFmt=SimpleDateFormat("EEE",Locale.US)
            val daily=linkedMapOf<String,Double>()
            val labels=linkedMapOf<String,String>()
            for(offset in 5 downTo 0){
                val c=Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR,-offset) }
                val key=dayFmt.format(c.time)
                daily[key]=0.0
                labels[key]=labelFmt.format(c.time)
            }
            history.forEach { line ->
                val x=line.split("|")
                if(x.size>=5){
                    val st=x[0].toLongOrNull()?:0L
                    val key=dayFmt.format(Date(st))
                    if(daily.containsKey(key)) daily[key]=(daily[key]?:0.0)+(x[4].toDoubleOrNull()?:0.0)
                }
            }
            val maxDaily=(daily.values.maxOrNull()?:0.0).coerceAtLeast(1.0)
            daily.forEach { (key,value) ->
                val col=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL }
                col.addView(txt(if(value>0) "$${f2(value)}" else "",8f,dim,false).apply{gravity=Gravity.CENTER})
                val bar=View(this).apply { background=rounded(green,green,0,2f) }
                val bh=if(value<=0) dp(2) else (dp(82)*(value/maxDaily)).toInt().coerceAtLeast(dp(8))
                col.addView(bar,LinearLayout.LayoutParams(dp(22),bh))
                col.addView(txt(labels[key].orEmpty(),9f,Color.WHITE,false).apply{gravity=Gravity.CENTER})
                bars.addView(col,LinearLayout.LayoutParams(0,dp(122),1f))
            }
            graph.addView(bars)
            host.addView(graph)
            gap(host,7)

            val mpg=prefs.getFloat("mpg",20f).toDouble().coerceAtLeast(1.0)
            val gas=prefs.getFloat("gas",3.99f).toDouble()
            val maint=prefs.getFloat("maintenance_per_mile",0.12f).toDouble()
            val costs=card()
            costs.addView(title("COST ESTIMATES"))
            costs.addView(div())
            costs.addView(valueRow("Gas (${f1(mpg)} mpg)","$${f2(miles/mpg*gas)}"))
            costs.addView(valueRow("Est. Maintenance","$${f2(miles*maint)}"))
            host.addView(costs)
        }

        listOf("DAY","WEEK","MONTH","YEAR").forEachIndexed { i,name ->
            val b=darkButton(name)
            b.setOnClickListener { selected=name;paint();render() }
            buttons[name]=b
            row.addView(b,LinearLayout.LayoutParams(0,dp(40),1f).apply { if(i>0) marginStart=dp(4) })
        }
        periodCard.addView(row)
        p.addView(periodCard)
        gap(p,7)
        p.addView(host)
        paint()
        render()
    }

    private fun buildAccounts(p: LinearLayout) {
        buildHeader(p)

        val apps=card()
        apps.addView(title("DRIVER APPS"))
        apps.addView(div())
        apps.addView(accountMockRow("D","DoorDash Dasher","Reader Mode Active","LAUNCH",red) {
            launchDriverApp(listOf("com.doordash.driverapp"),"DoorDash")
        })
        apps.addView(div())
        apps.addView(accountMockRow("UE","Uber Eats Driver","Not Connected","LAUNCH",green) {
            launchDriverApp(listOf("com.ubercab.driver","com.ubercab"),"Uber Driver")
        })
        p.addView(apps)
        gap(p,8)

        val connected=card()
        connected.addView(title("CONNECTED ACCOUNTS"))
        connected.addView(div())
        connected.addView(accountMockRow("U","Uber","Not Connected","CONNECT",green) {
            AlertDialog.Builder(this)
                .setTitle("Connect Uber")
                .setMessage("Official Uber OAuth is paused for now. Reader Mode can still track visible offers and local session data.")
                .setPositiveButton("OK",null).show()
        })
        connected.addView(infoBox("ⓘ","Uber account linking will use official OAuth authorization."))
        p.addView(connected)
        gap(p,8)

        val dd=card()
        dd.addView(title("DOORDASH ACCOUNT"))
        dd.addView(div())
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
        row.addView(txt("D",22f,red,true),LinearLayout.LayoutParams(dp(46),-2))
        row.addView(txt("Status: ",14f,Color.WHITE,false))
        row.addView(txt("Reader Mode",14f,green,true))
        dd.addView(row)
        dd.addView(txt("We read visible offers and session data on this device.\n\nDirect account linking will only be added if DoorDash provides official access.",11.5f,Color.WHITE,false))
        p.addView(dd)
    }

    private fun buildSettings(p: LinearLayout) {
        buildHeader(p)

        val vehicle=card()
        vehicle.addView(title("VEHICLE & COSTS"))
        vehicle.addView(div())
        vehicle.addView(settingRow("Vehicle MPG", f1(prefs.getFloat("mpg",20f).toDouble())) { editFloat("Vehicle MPG","mpg",20f) })
        vehicle.addView(settingRow("Gas Price / Gallon", "$${f2(prefs.getFloat("gas",3.99f).toDouble())}") { editFloat("Gas Price / Gallon","gas",3.99f) })
        vehicle.addView(settingRow("Maintenance / Mile", "$${f2(prefs.getFloat("maintenance_per_mile",0.12f).toDouble())}") { editFloat("Maintenance / Mile","maintenance_per_mile",0.12f) })
        p.addView(vehicle)
        gap(p,8)

        val targets=card()
        targets.addView(title("EARNINGS TARGETS"))
        targets.addView(div())
        targets.addView(settingRow("Minimum $ / Mile", "$${f2(prefs.getFloat("min_dpm",1.5f).toDouble())}") { editFloat("Minimum $ / Mile","min_dpm",1.5f) })
        targets.addView(settingRow("Preferred $ / Mile", "$${f2(prefs.getFloat("preferred_dpm",2f).toDouble())}") { editFloat("Preferred $ / Mile","preferred_dpm",2f) })
        targets.addView(settingRow("Minimum $ / Hour", "$${f2(prefs.getFloat("target_hour",25f).toDouble())}") { editFloat("Minimum $ / Hour","target_hour",25f) })
        p.addView(targets)
        gap(p,8)

        val auto=card()
        auto.addView(title("AUTO-STOP"))
        auto.addView(div())
        auto.addView(settingRow("Auto-stop after inactivity","${prefs.getInt("auto_stop_min",30)} minutes") {
            editInt("Auto-stop after inactivity","auto_stop_min",30,20,120)
        })
        auto.addView(txt("Dash will auto-end after no offers and no movement for the selected time.",11f,dim,false).apply{setPadding(0,dp(6),0,0)})
        p.addView(auto)
        gap(p,8)

        val notices=card()
        notices.addView(title("NOTIFICATIONS"))
        notices.addView(div())
        notices.addView(toggleRow("Offer Alerts","offer_alerts",true))
        notices.addView(toggleRow("Auto-stop Warning","autostop_warning",true))
        p.addView(notices)
    }

    private fun buildTaxes(p: LinearLayout) {
        buildHeader(p)

        val ex=card()
        ex.addView(title("EXPORT RECORDS"))
        ex.addView(div())
        ex.addView(txt("Export your earnings and mileage records for taxes.",11.5f,Color.WHITE,false))
        val csv=neonButton("EXPORT CSV")
        csv.setOnClickListener { exportTaxCsv() }
        ex.addView(csv,LinearLayout.LayoutParams(-1,dp(45)).apply{topMargin=dp(8)})
        val pdf=outlineButton("EXPORT PDF (SUMMARY)",green)
        pdf.setOnClickListener { Toast.makeText(this,"PDF summary export is coming in the next data/reporting patch.",Toast.LENGTH_LONG).show() }
        ex.addView(pdf,LinearLayout.LayoutParams(-1,dp(45)).apply{topMargin=dp(6)})
        p.addView(ex)
        gap(p,8)

        val yearMiles=calculateYearMiles()
        val log=card()
        log.addView(title("MILEAGE LOG"))
        log.addView(div())
        log.addView(settingRow("Total Miles (This Year)",f1(yearMiles)) { })
        log.addView(settingRow("Deductible Miles",f1(yearMiles)) { })
        p.addView(log)
        gap(p,8)

        val taxYear=card()
        taxYear.addView(settingRow("TAX YEAR",SimpleDateFormat("yyyy",Locale.US).format(Date())) { })
        p.addView(taxYear)
        gap(p,8)

        val sum=card()
        sum.addView(title("TAX SUMMARY (${SimpleDateFormat("yyyy",Locale.US).format(Date())})"))
        sum.addView(div())
        sum.addView(valueRow("Earnings","$${f2(calculateYearEarnings())}"))
        sum.addView(valueRow("Miles",f1(yearMiles)))
        p.addView(sum)
    }

    private fun rebuildNav() {
        nav.removeAllViews()
        listOf(
            "Home" to "⌂",
            "History" to "▣",
            "Reports" to "▥",
            "Accounts" to "♙",
            "Settings" to "⚙",
            "Taxes" to "▤"
        ).forEach { (name,ico) ->
            val item=TextView(this).apply {
                text="$ico\n$name"
                textSize=9.2f
                gravity=Gravity.CENTER
                setTextColor(if(name==currentTab) green else Color.WHITE)
                if(name==currentTab) setTypeface(typeface,Typeface.BOLD)
                setOnClickListener { showTab(name) }
            }
            nav.addView(item,LinearLayout.LayoutParams(0,-1,1f))
        }
    }

    private fun driverLaunch(name:String, action:String, color:Int):View {
        val b=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER
            background=rounded(Color.argb(235,2,8,4),color,2,9f)
            setPadding(dp(8),0,dp(8),0)
        }
        b.addView(txt(if(name.contains("DOOR")) "D" else "UE",13f,color,true))
        b.addView(txt("  $action\n$name",11f,Color.WHITE,true).apply{gravity=Gravity.CENTER})
        return b
    }

    private fun accountMockRow(mark:String,name:String,status:String,button:String,color:Int,onClick:()->Unit):View {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(3),0,dp(3)) }
        row.addView(txt(mark,16f,color,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(45),dp(42)))
        val text=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        text.addView(txt(name,13.5f,Color.WHITE,false))
        text.addView(txt(status,11f,if(status.contains("Active")) green else dim,false))
        row.addView(text,LinearLayout.LayoutParams(0,-2,1f))
        val btn=outlineButton(button,color)
        btn.setOnClickListener { onClick() }
        row.addView(btn,LinearLayout.LayoutParams(dp(94),dp(42)))
        return row
    }

    private fun infoBox(icon:String,message:String):View {
        val row=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(10),dp(10),dp(10),dp(10))
            background=rounded(Color.rgb(3,12,8),Color.rgb(45,70,55),1,8f)
        }
        row.addView(txt(icon,18f,Color.CYAN,false),LinearLayout.LayoutParams(dp(36),-2))
        row.addView(txt(message,11f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f))
        return row
    }

    private fun settingRow(label:String,value:String,onClick:()->Unit):View {
        val row=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(0,dp(6),0,dp(6))
            setOnClickListener { onClick() }
        }
        row.addView(txt(label,12.5f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f))
        row.addView(txt(value,12.5f,green,false))
        row.addView(txt("  ›",17f,green,false))
        return row
    }

    private fun toggleRow(label:String,key:String,default:Boolean):View {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(4),0,dp(4)) }
        row.addView(txt(label,12.5f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f))
        val sw=Switch(this).apply {
            isChecked=prefs.getBoolean(key,default)
            setOnCheckedChangeListener { _,checked -> prefs.edit().putBoolean(key,checked).apply() }
        }
        row.addView(sw)
        return row
    }

    private fun editFloat(title:String,key:String,default:Float) {
        val input=EditText(this).apply {
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getFloat(key,default).toString())
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("SAVE"){_,_->
                input.text.toString().toFloatOrNull()?.let { prefs.edit().putFloat(key,it.coerceAtLeast(0f)).apply() }
                showTab("Settings")
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun editInt(title:String,key:String,default:Int,min:Int,max:Int) {
        val input=EditText(this).apply {
            inputType=InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt(key,default).toString())
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("SAVE"){_,_->
                input.text.toString().toIntOrNull()?.let { prefs.edit().putInt(key,it.coerceIn(min,max)).apply() }
                showTab("Settings")
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun mockMetric(label:String,value:String,sub:String):Pair<LinearLayout,TextView> {
        val b=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(2),dp(2),dp(2),dp(2)) }
        b.addView(txt(label,9.5f,Color.WHITE,false))
        val v=txt(value,18f,green,true).apply{gravity=Gravity.CENTER}
        b.addView(v)
        if(sub.isNotBlank()) b.addView(txt(sub,9.5f,dim,false).apply{gravity=Gravity.CENTER})
        return Pair(b,v)
    }

    private fun tinyRule(icon:String,label:String,value:String):View {
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER}
        b.addView(txt("$icon  $label",9.5f,Color.WHITE,false).apply{gravity=Gravity.CENTER})
        b.addView(txt(value,10.5f,Color.WHITE,true).apply{gravity=Gravity.CENTER})
        return b
    }

    private fun statTile(label:String,value:String):View {
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            background=rounded(Color.rgb(3,12,8),cardStroke,1,8f)
            addView(txt(label,10.5f,Color.WHITE,false).apply{gravity=Gravity.CENTER})
            addView(txt(value,17f,green,true).apply{gravity=Gravity.CENTER})
        }
    }

    private fun sectionLabel(s:String):View {
        return txt(s,12f,Color.WHITE,true).apply{setPadding(dp(4),dp(2),0,dp(5))}
    }

    private fun startDash() {
        val req=mutableListOf<String>()
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) req+=Manifest.permission.ACCESS_FINE_LOCATION
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) req+=Manifest.permission.POST_NOTIFICATIONS
        if(req.isNotEmpty()) {
            requestPermissions(req.toTypedArray(),77)
            Toast.makeText(this,"Allow location, then tap START DASH again.",Toast.LENGTH_LONG).show()
        } else {
            startForegroundService(Intent(this,MileageService::class.java).setAction("START"))
        }
    }

    private fun launchDriverApp(packages:List<String>,label:String) {
        val platform=if(label.contains("DoorDash",true)) "DoorDash" else "Uber Eats"
        prefs.edit().putString("current_platform",platform).apply()
        for(pkg in packages) {
            packageManager.getLaunchIntentForPackage(pkg)?.let {
                runCatching { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(it) }.onSuccess { return }
            }
            val explicit=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
            val ri=packageManager.queryIntentActivities(explicit,0).firstOrNull()
            if(ri!=null) {
                val cn=ComponentName(ri.activityInfo.packageName,ri.activityInfo.name)
                runCatching {
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onSuccess { return }
            }
        }
        Toast.makeText(this,"Could not open $label. Check that the driver app is installed and enabled.",Toast.LENGTH_LONG).show()
    }

    private fun calculateYearMiles():Double {
        val c=Calendar.getInstance().apply {
            set(Calendar.DAY_OF_YEAR,1);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
        }
        val start=c.timeInMillis
        var total=0.0
        prefs.getString("dash_history","").orEmpty().lines().filter{it.isNotBlank()}.forEach { line ->
            val x=line.split("|")
            if(x.size>=3 && (x[1].toLongOrNull()?:0L)>=start) total+=x[2].toDoubleOrNull()?:0.0
        }
        return total
    }

    private fun calculateYearEarnings():Double {
        val c=Calendar.getInstance().apply {
            set(Calendar.DAY_OF_YEAR,1);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
        }
        val start=c.timeInMillis
        var total=0.0
        prefs.getString("dash_history","").orEmpty().lines().filter{it.isNotBlank()}.forEach { line ->
            val x=line.split("|")
            if(x.size>=5 && (x[1].toLongOrNull()?:0L)>=start) total+=x[4].toDoubleOrNull()?:0.0
        }
        return total
    }

    private fun exportTaxCsv() {
        val name="DeliveryDecision_${SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())}.csv"
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type="text/csv"
            putExtra(Intent.EXTRA_TITLE,name)
        },901)
    }

    @Deprecated("framework")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=901 || resultCode!=RESULT_OK) return
        val uri=data?.data?:return
        val history=prefs.getString("dash_history","").orEmpty()
        val csv=buildString {
            appendLine("Start,End,Platform,Miles,Earnings")
            history.lines().filter{it.isNotBlank()}.forEach { line ->
                val x=line.split("|")
                if(x.size>=3) {
                    val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US)
                    val st=x[0].toLongOrNull()?:0L
                    val en=x[1].toLongOrNull()?:0L
                    val platform=if(x.size>=4)x[3] else "Delivery"
                    val earnings=if(x.size>=5)x[4] else "0"
                    appendLine("${fmt.format(Date(st))},${fmt.format(Date(en))},$platform,${x[2]},$earnings")
                }
            }
        }
        runCatching {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
        }.onSuccess {
            Toast.makeText(this,"CSV saved",Toast.LENGTH_LONG).show()
        }.onFailure {
            Toast.makeText(this,"Could not save CSV",Toast.LENGTH_LONG).show()
        }
    }

    private fun isAccessibilityEnabled():Boolean {
        val enabled=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?:return false
        return enabled.contains("$packageName/.OfferReaderService",true) || enabled.contains("com.deliverydecision",true)
    }

    private fun card()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(dp(11),dp(9),dp(11),dp(9))
        background=rounded(cardFill,cardStroke,1,12f)
    }

    private fun title(s:String)=txt(s,15f,Color.WHITE,true)

    private fun div()=View(this).apply {
        setBackgroundColor(Color.rgb(58,82,50))
        layoutParams=LinearLayout.LayoutParams(-1,1).apply{topMargin=dp(5);bottomMargin=dp(5)}
    }

    private fun valueRow(label:String,value:String):View {
        val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,dp(6)) }
        r.addView(txt(label,12.5f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f))
        r.addView(txt(value,13f,green,false))
        return r
    }

    private fun neonButton(s:String)=Button(this).apply {
        text=s;textSize=13f;setTextColor(Color.BLACK);setTypeface(typeface,Typeface.BOLD)
        background=rounded(green,green,0,8f)
        setPadding(dp(4),0,dp(4),0)
    }

    private fun outlineButton(s:String,c:Int)=Button(this).apply {
        text=s;textSize=11f;setTextColor(c);setTypeface(typeface,Typeface.BOLD)
        background=rounded(Color.argb(240,2,7,4),c,2,8f)
        setPadding(dp(3),0,dp(3),0)
    }

    private fun darkButton(s:String)=Button(this).apply {
        text=s;textSize=10.5f;setTextColor(Color.WHITE)
        background=rounded(Color.rgb(8,11,8),Color.rgb(65,75,65),1,8f)
        setPadding(dp(2),0,dp(2),0)
    }

    private fun txt(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply {
        text=s;textSize=size;setTextColor(color)
        if(bold)setTypeface(typeface,Typeface.BOLD)
    }

    private fun rounded(fill:Int,stroke:Int,strokeW:Int,r:Float)=GradientDrawable().apply {
        setColor(fill)
        cornerRadius=dp(r.toInt()).toFloat()
        if(strokeW>0)setStroke(dp(strokeW),stroke)
    }

    private fun gap(p:LinearLayout,h:Int)=p.addView(Space(this),LinearLayout.LayoutParams(1,dp(h)))
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun f1(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun f2(v:Double)=String.format(Locale.US,"%.2f",v)

    private fun formatDuration(ms:Long):String {
        val s=(ms.coerceAtLeast(0L))/1000
        return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60)
    }

    private fun hhmm(ms:Long):String {
        val s=(ms.coerceAtLeast(0L))/1000
        return String.format(Locale.US,"%02d:%02d",s/3600,(s%3600)/60)
    }
}
