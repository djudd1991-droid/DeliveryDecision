package com.deliverydecision

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.*
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var mpg: EditText
    private lateinit var gas: EditText
    private lateinit var minDpm: EditText
    private lateinit var prefDpm: EditText
    private lateinit var targetHr: EditText

    private lateinit var dashStatus: TextView
    private lateinit var todayMiles: TextView
    private lateinit var weekMiles: TextView
    private lateinit var monthMiles: TextView
    private lateinit var activeTime: TextView
    private lateinit var gasCost: TextView

    private lateinit var earningsValue: TextView
    private lateinit var actualMilesValue: TextView
    private lateinit var actualDpmValue: TextView
    private lateinit var actualHrValue: TextView

    private val green = Color.rgb(140,255,0)
    private val red = Color.rgb(255,65,54)
    private val gold = Color.rgb(255,214,0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        ui.post(refresh)
    }

    private val refresh = object : Runnable {
        override fun run() {
            val active = prefs.getBoolean("dash_active", false)
            val today = prefs.getFloat("today_miles",0f).toDouble()
            val week = prefs.getFloat("week_miles",0f).toDouble()
            val month = prefs.getFloat("month_miles",0f).toDouble()
            val start = prefs.getLong("dash_start",0L)
            val activeMs = if (active && start > 0) System.currentTimeMillis()-start else prefs.getLong("last_session_ms",0L)
            val mpgV = prefs.getFloat("mpg",20f).toDouble().coerceAtLeast(1.0)
            val gasV = prefs.getFloat("gas",3.99f).toDouble()
            val earnings = prefs.getFloat("today_earnings",0f).toDouble()
            val dpm = if (today > 0) earnings/today else 0.0
            val hr = if (activeMs > 0) earnings/(activeMs/3600000.0) else 0.0

            dashStatus.text = if (active) "ACTIVE  ●" else "NOT ACTIVE  ○"
            dashStatus.setTextColor(if (active) green else Color.LTGRAY)
            todayMiles.text = "${f1(today)} mi"
            weekMiles.text = "${f1(week)} mi"
            monthMiles.text = "${f1(month)} mi"
            activeTime.text = formatDuration(activeMs)
            gasCost.text = "$${f2(today/mpgV*gasV)}"

            earningsValue.text = "$${f2(earnings)}"
            actualMilesValue.text = "${f1(today)} mi"
            actualDpmValue.text = "$${f2(dpm)}"
            actualHrValue.text = "$${f2(hr)}"

            ui.postDelayed(this,1000L)
        }
    }

    private fun buildUi() {
        val frame = FrameLayout(this)
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.money_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        frame.addView(bg, FrameLayout.LayoutParams(-1,-1))

        val shade = View(this).apply { setBackgroundColor(Color.argb(120,0,0,0)) }
        frame.addView(shade, FrameLayout.LayoutParams(-1,-1))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18),dp(14),dp(18),dp(28))
        }
        scroll.addView(content)
        frame.addView(scroll)
        setContentView(frame)

        // HEADER
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0,0,0,dp(10))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.argb(230,0,0,0), green, 2, 20f)
            setPadding(dp(3),dp(3),dp(3),dp(3))
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(112),dp(112)).apply { marginEnd=dp(14) })

        val ht = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        ht.addView(txt("Delivery Decision",27f,Color.WHITE,true))
        ht.addView(txt("v0.2.1",19f,green,true))
        ht.addView(txt("Reads visible offers and shows",14f,Color.LTGRAY,false))
        val decisions = TextView(this).apply {
            text = "TAKE   •   CONSIDER   •   PASS"
            textSize=15f
            setTypeface(typeface,Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        ht.addView(decisions)
        header.addView(ht,LinearLayout.LayoutParams(0,-2,1f))
        content.addView(header)

        // RULES
        val rules = card()
        rules.addView(sectionTitle("YOUR RULES"))
        rules.addView(smallDivider())
        mpg = settingRow(rules,"◉","MPG (Fuel Efficiency)","Your vehicle's average MPG",prefs.getFloat("mpg",20f).toString())
        gas = settingRow(rules,"⛽","Gas Price ($/gal)","Current price per gallon",prefs.getFloat("gas",3.99f).toString())
        minDpm = settingRow(rules,"$","Minimum $/mile","Minimum you'll accept per mile",prefs.getFloat("min_dpm",1.5f).toString())
        prefDpm = settingRow(rules,"↗","Preferred $/mile","Preferred rate per mile",prefs.getFloat("preferred_dpm",2f).toString())
        targetHr = settingRow(rules,"◷","Target $/hour","Minimum you want per hour",prefs.getFloat("target_hour",25f).toString())
        val save = neonButton("▣   SAVE SETTINGS")
        save.setOnClickListener {
            prefs.edit()
                .putFloat("mpg",num(mpg,20f))
                .putFloat("gas",num(gas,3.99f))
                .putFloat("min_dpm",num(minDpm,1.5f))
                .putFloat("preferred_dpm",num(prefDpm,2f))
                .putFloat("target_hour",num(targetHr,25f))
                .apply()
            Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show()
        }
        rules.addView(save,LinearLayout.LayoutParams(-1,dp(58)).apply { topMargin=dp(8) })
        rules.addView(centerHint("✓  Settings are saved on this phone."))
        content.addView(rules)
        gap(content,14)

        // MILEAGE
        val mileage = card()
        mileage.addView(sectionTitle("MILEAGE TRACKER"))
        mileage.addView(smallDivider())

        val statusRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        statusRow.addView(txt("DASH STATUS",13f,Color.LTGRAY,true),LinearLayout.LayoutParams(0,-2,1f))
        dashStatus = txt("",15f,green,true)
        statusRow.addView(dashStatus)
        mileage.addView(statusRow)

        mileage.addView(txt("TODAY (Live)",13f,Color.LTGRAY,true))
        todayMiles = txt("0.0 mi",36f,green,true)
        mileage.addView(todayMiles)

        val two = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val left = metricMini("TIME ACTIVE").also { activeTime = it.second }
        val right = metricMini("EST. GAS COST").also { gasCost = it.second }
        two.addView(left.first,LinearLayout.LayoutParams(0,-2,1f))
        two.addView(right.first,LinearLayout.LayoutParams(0,-2,1f))
        mileage.addView(two)
        mileage.addView(grayDivider())

        val weekRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val wtxt = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        wtxt.addView(txt("THIS WEEK",13f,Color.LTGRAY,true))
        weekMiles = txt("0.0 mi",26f,green,true)
        wtxt.addView(weekMiles)
        weekRow.addView(wtxt,LinearLayout.LayoutParams(0,-2,1f))
        val mtxt = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        mtxt.addView(txt("THIS MONTH",13f,Color.LTGRAY,true))
        monthMiles = txt("0.0 mi",26f,green,true)
        mtxt.addView(monthMiles)
        weekRow.addView(mtxt,LinearLayout.LayoutParams(0,-2,1f))
        mileage.addView(weekRow)

        val start = outlineButton("▶  START DASH",green)
        val end = outlineButton("■  END DASH",red)
        start.setOnClickListener { startDash() }
        end.setOnClickListener { startService(Intent(this,MileageService::class.java).setAction("STOP")) }
        mileage.addView(start,LinearLayout.LayoutParams(-1,dp(56)).apply { topMargin=dp(8) })
        mileage.addView(end,LinearLayout.LayoutParams(-1,dp(56)).apply { topMargin=dp(8) })

        val correct = darkButton("CORRECT TODAY'S MILES")
        correct.setOnClickListener { correctMiles() }
        mileage.addView(correct,LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(8) })
        mileage.addView(centerHint("Auto-stop: 90 minutes with no movement and no offer activity."))
        content.addView(mileage)
        gap(content,14)

        // SUMMARY
        val summary = card()
        summary.addView(sectionTitle("TODAY'S SUMMARY"))
        summary.addView(smallDivider())

        val sumGrid1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val a = summaryMetric("EARNINGS")
        earningsValue = a.second
        val b = summaryMetric("MILES DRIVEN")
        actualMilesValue = b.second
        sumGrid1.addView(a.first,LinearLayout.LayoutParams(0,-2,1f))
        sumGrid1.addView(b.first,LinearLayout.LayoutParams(0,-2,1f))
        summary.addView(sumGrid1)

        val sumGrid2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val c = summaryMetric("$ / MILE (ACTUAL)")
        actualDpmValue = c.second
        val d = summaryMetric("$ / HOUR (ACTIVE)")
        actualHrValue = d.second
        sumGrid2.addView(c.first,LinearLayout.LayoutParams(0,-2,1f))
        sumGrid2.addView(d.first,LinearLayout.LayoutParams(0,-2,1f))
        summary.addView(sumGrid2)

        val earningsBtn = darkButton("SET TODAY'S EARNINGS")
        earningsBtn.setOnClickListener { setEarnings() }
        summary.addView(earningsBtn,LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(8) })
        val hist = darkButton("▤   VIEW DASH HISTORY   ›")
        hist.setOnClickListener { showHistory() }
        summary.addView(hist,LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(8) })
        content.addView(summary)
        gap(content,14)

        // OFFER READER
        val offer = card()
        val orow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val target = TextView(this).apply { text="◎"; textSize=36f; setTextColor(green); gravity=Gravity.CENTER }
        orow.addView(target,LinearLayout.LayoutParams(dp(56),dp(56)))
        val ot = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        ot.addView(txt("ENABLE OFFER READER",20f,Color.WHITE,true))
        ot.addView(txt("Turn on the overlay to analyze visible offers.",13f,Color.LTGRAY,false))
        orow.addView(ot,LinearLayout.LayoutParams(0,-2,1f))
        val sw = Switch(this).apply {
            isChecked = isAccessibilityEnabled()
            buttonTintList = null
            setOnCheckedChangeListener { _, checked ->
                if (checked && !isAccessibilityEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                if (!checked && isAccessibilityEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        orow.addView(sw)
        offer.addView(orow)
        content.addView(offer)
        gap(content,14)

        // Bottom nav look
        val nav = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER
            setPadding(dp(4),dp(8),dp(4),dp(8))
            background = rounded(Color.argb(235,5,5,5),Color.DKGRAY,1,18f)
        }
        nav.addView(navItem("⌂\nHome",true),LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(navItem("▥\nHistory",false),LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(navItem("⚙\nSettings",false),LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(navItem("ⓘ\nAbout",false),LinearLayout.LayoutParams(0,-2,1f))
        content.addView(nav)
    }

    private fun startDash() {
        val req = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            req += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            req += Manifest.permission.POST_NOTIFICATIONS
        if (req.isNotEmpty()) {
            requestPermissions(req.toTypedArray(),77)
            Toast.makeText(this,"Allow location, then tap START DASH again.",Toast.LENGTH_LONG).show()
        } else startForegroundService(Intent(this,MileageService::class.java).setAction("START"))
    }

    private fun setEarnings() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getFloat("today_earnings",0f).toString())
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this).setTitle("Today's earnings")
            .setMessage("Enter your total delivery earnings for today.")
            .setView(input)
            .setPositiveButton("SAVE"){_,_->
                prefs.edit().putFloat("today_earnings",(input.text.toString().toFloatOrNull()?:0f).coerceAtLeast(0f)).apply()
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun correctMiles() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getFloat("today_miles",0f).toString())
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this).setTitle("Correct today's miles")
            .setMessage("Enter the correct total delivery miles for today.")
            .setView(input)
            .setPositiveButton("SAVE"){_,_->
                val nm=(input.text.toString().toFloatOrNull()?:return@setPositiveButton).coerceAtLeast(0f)
                val old=prefs.getFloat("today_miles",0f)
                val delta=nm-old
                prefs.edit()
                    .putFloat("today_miles",nm)
                    .putFloat("week_miles",(prefs.getFloat("week_miles",0f)+delta).coerceAtLeast(0f))
                    .putFloat("month_miles",(prefs.getFloat("month_miles",0f)+delta).coerceAtLeast(0f))
                    .apply()
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun showHistory() {
        val raw=prefs.getString("dash_history","").orEmpty()
        val lines=raw.lines().filter{it.isNotBlank()}.takeLast(12).reversed()
        val fmt=SimpleDateFormat("MMM d, h:mm a",Locale.US)
        val body=if(lines.isEmpty()) "No completed dash sessions yet." else lines.joinToString("\n\n"){
            val p=it.split("|")
            if(p.size>=3){
                val st=p[0].toLongOrNull()?:0L
                val en=p[1].toLongOrNull()?:0L
                val mi=p[2].toFloatOrNull()?:0f
                "${fmt.format(Date(st))}  •  ${f1(mi.toDouble())} mi  •  ${formatDuration((en-st).coerceAtLeast(0L))}"
            } else it
        }
        AlertDialog.Builder(this).setTitle("Dash history").setMessage(body).setPositiveButton("OK",null).show()
    }

    private fun isAccessibilityEnabled():Boolean {
        val enabled=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/.OfferReaderService",true) || enabled.contains("com.deliverydecision",true)
    }

    private fun settingRow(parent:LinearLayout, symbol:String, title:String, sub:String, value:String):EditText {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(10),0,dp(10)) }
        val ico=TextView(this).apply { text=symbol; textSize=28f; setTextColor(green); gravity=Gravity.CENTER }
        row.addView(ico,LinearLayout.LayoutParams(dp(52),dp(60)))
        val texts=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        texts.addView(txt(title,17f,Color.WHITE,true))
        texts.addView(txt(sub,12f,Color.LTGRAY,false))
        row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
        val edit=EditText(this).apply {
            setText(value); textSize=17f; gravity=Gravity.CENTER; setTextColor(Color.WHITE)
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background=rounded(Color.rgb(8,12,8),green,1,14f)
        }
        row.addView(edit,LinearLayout.LayoutParams(dp(112),dp(58)))
        parent.addView(row)
        parent.addView(grayDivider())
        return edit
    }

    private fun metricMini(title:String):Pair<LinearLayout,TextView> {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(8),0,dp(8)) }
        box.addView(txt(title,12f,Color.LTGRAY,true))
        val value=txt("0",22f,Color.WHITE,true)
        box.addView(value)
        return Pair(box,value)
    }

    private fun summaryMetric(title:String):Pair<LinearLayout,TextView> {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(6),dp(10),dp(6),dp(10)) }
        box.addView(txt(title,11f,Color.LTGRAY,true))
        val value=txt("0",25f,green,true)
        box.addView(value)
        return Pair(box,value)
    }

    private fun card()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(dp(18),dp(16),dp(18),dp(16))
        background=rounded(Color.argb(238,3,7,3),green,2,22f)
    }
    private fun sectionTitle(s:String)=txt(s,22f,green,true)
    private fun smallDivider()=View(this).apply {
        setBackgroundColor(green)
        layoutParams=LinearLayout.LayoutParams(dp(62),dp(3)).apply { topMargin=dp(4); bottomMargin=dp(8) }
    }
    private fun grayDivider()=View(this).apply {
        setBackgroundColor(Color.rgb(55,60,55))
        layoutParams=LinearLayout.LayoutParams(-1,1)
    }
    private fun centerHint(s:String)=txt(s,12f,Color.LTGRAY,false).apply { gravity=Gravity.CENTER; setPadding(0,dp(9),0,0) }
    private fun neonButton(s:String)=Button(this).apply {
        text=s; textSize=17f; setTextColor(Color.BLACK); setTypeface(typeface,Typeface.BOLD)
        background=rounded(green,green,0,16f)
    }
    private fun outlineButton(s:String,color:Int)=Button(this).apply {
        text=s; textSize=16f; setTextColor(color); setTypeface(typeface,Typeface.BOLD)
        background=rounded(Color.argb(230,3,6,3),color,2,14f)
    }
    private fun darkButton(s:String)=Button(this).apply {
        text=s; textSize=14f; setTextColor(Color.WHITE)
        background=rounded(Color.rgb(9,10,9),Color.rgb(90,100,90),1,14f)
    }
    private fun navItem(s:String,active:Boolean)=TextView(this).apply {
        text=s; textSize=12f; gravity=Gravity.CENTER; setTextColor(if(active) green else Color.LTGRAY)
        if(active) setTypeface(typeface,Typeface.BOLD)
    }
    private fun txt(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color)
        if(bold) setTypeface(typeface,Typeface.BOLD)
    }
    private fun rounded(fill:Int,stroke:Int,strokeW:Int,r:Float)=GradientDrawable().apply {
        setColor(fill); cornerRadius=dp(r.toInt()).toFloat()
        if(strokeW>0) setStroke(dp(strokeW),stroke)
    }
    private fun gap(p:LinearLayout,h:Int)=p.addView(Space(this),LinearLayout.LayoutParams(1,dp(h)))
    private fun num(e:EditText,f:Float)=e.text.toString().toFloatOrNull()?:f
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun f1(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun f2(v:Double)=String.format(Locale.US,"%.2f",v)
    private fun formatDuration(ms:Long):String {
        val s=ms/1000
        return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60)
    }
}
