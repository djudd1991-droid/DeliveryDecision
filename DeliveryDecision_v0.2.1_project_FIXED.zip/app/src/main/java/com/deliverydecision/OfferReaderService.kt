package com.deliverydecision

import android.accessibilityservice.AccessibilityService
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.*
import java.util.regex.Pattern
import kotlin.math.max

data class Offer(val pay:Double,val miles:Double,val minutes:Double?)

object OfferParser {
    private val money=Pattern.compile("\\$(\\d+(?:\\.\\d{1,2})?)")
    private val miles=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(?:mi|miles)",Pattern.CASE_INSENSITIVE)
    private val mins=Pattern.compile("(\\d{1,3})\\s*(?:min|mins|minutes)",Pattern.CASE_INSENSITIVE)

    fun parse(text:String):Offer? {
        val m=money.matcher(text); val d=miles.matcher(text)
        if(!m.find()||!d.find()) return null
        val pay=m.group(1)?.toDoubleOrNull()?:return null
        val dist=d.group(1)?.toDoubleOrNull()?:return null
        if(pay<=0||dist<=0||pay>500||dist>200) return null
        val tm=mins.matcher(text)
        val minutes=if(tm.find()) tm.group(1)?.toDoubleOrNull() else null
        return Offer(pay,dist,minutes)
    }
}

class OfferReaderService:AccessibilityService(){
    private val prefs by lazy { getSharedPreferences("dd",MODE_PRIVATE) }
    private val h=Handler(Looper.getMainLooper())
    private var overlay:TextView?=null
    private var shownKey=""
    private var lastSeen=0L
    private val hideRunnable=Runnable {
        if(System.currentTimeMillis()-lastSeen>5000L){ hide(); shownKey="" }
    }

    override fun onAccessibilityEvent(event:AccessibilityEvent?){
        val pkg=event?.packageName?.toString()?:return
        if(pkg==packageName) return
        val supported=pkg=="com.doordash.driverapp" || pkg=="com.ubercab.driver" || pkg=="com.ubercab"
        if(!supported) return

        val root=rootInActiveWindow?:return
        val offer=OfferParser.parse(collect(root))?:return
        lastSeen=System.currentTimeMillis()
        prefs.edit().putLong("last_offer_seen",lastSeen).apply()
        h.removeCallbacks(hideRunnable); h.postDelayed(hideRunnable,5500L)

        val key="$pkg|${offer.pay}|${offer.miles}|${offer.minutes}"
        if(key==shownKey && overlay!=null) return
        shownKey=key
        show(pkg,offer)
    }

    private fun collect(node:AccessibilityNodeInfo):String{
        val sb=StringBuilder()
        fun walk(n:AccessibilityNodeInfo?){
            if(n==null)return
            n.text?.let{sb.append(it).append(' ')}
            n.contentDescription?.let{sb.append(it).append(' ')}
            for(i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(node); return sb.toString()
    }

    private fun show(pkg:String,o:Offer){
        val mpg=prefs.getFloat("mpg",20f).toDouble().coerceAtLeast(1.0)
        val gas=prefs.getFloat("gas",3.99f).toDouble()
        val min=prefs.getFloat("min_dpm",1.5f).toDouble()
        val pref=prefs.getFloat("preferred_dpm",2f).toDouble()
        val target=prefs.getFloat("target_hour",25f).toDouble()
        val dpm=o.pay/max(o.miles,.1)
        val fuel=o.miles/mpg*gas
        val after=o.pay-fuel
        val hourly=o.minutes?.takeIf{it in 5.0..180.0}?.let{o.pay/(it/60.0)}
        val decision=when{
            dpm>=pref && (hourly==null || hourly>=target) -> "TAKE"
            dpm>=min -> "CONSIDER"
            else -> "PASS"
        }
        val color=when(decision){
            "TAKE"->Color.rgb(140,255,0)
            "CONSIDER"->Color.rgb(255,214,0)
            else->Color.rgb(255,65,54)
        }
        val app=if(pkg.contains("doordash"))"DoorDash" else "Uber Eats"
        val hour=hourly?.let{"  •  ~$${f2(it)}/hr"}.orEmpty()
        val text="●  $decision   $app\n$${f2(o.pay)}  •  ${f1(o.miles)} mi  •  $${f2(dpm)}/mi$hour\nFuel ~$${f2(fuel)}  •  After fuel ~$${f2(after)}"

        h.post{
            if(overlay==null){
                overlay=TextView(this).apply{
                    textSize=15f; setTextColor(Color.WHITE); setPadding(22,14,22,14)
                }
                val lp=WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply{ gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL; y=110 }
                getSystemService(WindowManager::class.java).addView(overlay,lp)
            }
            overlay?.background=GradientDrawable().apply{
                setColor(Color.argb(246,2,7,2)); setStroke(3,color); cornerRadius=24f
            }
            overlay?.text=text
        }
    }

    private fun hide(){
        h.post{
            overlay?.let{runCatching{getSystemService(WindowManager::class.java).removeView(it)}}
            overlay=null
        }
    }

    private fun f1(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun f2(v:Double)=String.format(Locale.US,"%.2f",v)
    override fun onInterrupt()=Unit
}
