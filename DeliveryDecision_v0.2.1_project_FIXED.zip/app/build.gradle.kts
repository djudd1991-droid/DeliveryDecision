plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.deliverydecision"
    compileSdk = 36

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.deliverydecision"
        minSdk = 26
        targetSdk = 36
        versionCode = 21
        versionName = "0.2.1"
    }
}

kotlin { jvmToolchain(17) }
