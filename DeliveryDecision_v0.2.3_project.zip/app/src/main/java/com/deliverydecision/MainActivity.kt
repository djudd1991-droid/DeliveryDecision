package com.deliverydecision

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())
    private val green = Color.rgb(170,255,0)
    private val red = Color.rgb(255,65,54)
    private val dim = Color.rgb(170,180,170)
    private lateinit var pageHost: FrameLayout
    private lateinit var nav: LinearLayout
    private var currentTab = "Home"
    private var liveEarnings: TextView? = null
    private var liveMiles: TextView? = null
    private var liveTime: TextView? = null
    private var liveStatus: TextView? = null
    private var liveAuto: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(2,8,2)
        window.navigationBarColor = Color.rgb(2,8,2)
        buildShell()
        showTab("Home")
        ui.post(refresh)
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }

    private val refresh = object: Runnable {
        override fun run() {
            if (currentTab == "Home") updateHomeLive()
            ui.postDelayed(this,1000L)
        }
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(1,5,1)) }
        pageHost = FrameLayout(this)
        root.addView(pageHost, LinearLayout.LayoutParams(-1,0,1f))
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(3),dp(5),dp(3),dp(8))
            background = rounded(Color.rgb(3,9,3), green, 1, 14f)
        }
        root.addView(nav, LinearLayout.LayoutParams(-1,dp(70)))
        setContentView(root)
    }

    private fun showTab(tab:String) {
        currentTab = tab
        pageHost.removeAllViews()
        pageHost.addView(pageBackground())
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14),dp(10),dp(14),dp(18))
        }
        scroll.addView(content)
        pageHost.addView(scroll,FrameLayout.LayoutParams(-1,-1))
        when(tab) {
            "Home" -> buildHome(content)
            "History" -> buildHistory(content)
            "Reports" -> buildReports(content)
            "Accounts" -> buildAccounts(content)
            "Settings" -> buildSettings(content)
            "Taxes" -> buildTaxes(content)
        }
        rebuildNav()
    }

    private fun pageBackground(): View {
        val frame = FrameLayout(this)
        val bg = ImageView(this).apply { setImageResource(R.drawable.money_bg); scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(bg,FrameLayout.LayoutParams(-1,-1))
        val shade = View(this).apply { setBackgroundColor(Color.argb(78,0,0,0)) }
        frame.addView(shade,FrameLayout.LayoutParams(-1,-1))
        return frame
    }

    private fun buildHeader(parent:LinearLayout,title:String,subtitle:String="") {
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,0,0,dp(10)) }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.app_icon); scaleType=ImageView.ScaleType.CENTER_CROP
            background=rounded(Color.argb(210,0,0,0),green,2,18f); setPadding(dp(2),dp(2),dp(2),dp(2))
        }
        row.addView(icon,LinearLayout.LayoutParams(dp(78),dp(78)).apply{marginEnd=dp(12)})
        val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        texts.addView(txt(title,25f,Color.WHITE,true))
        if(subtitle.isNotBlank()) texts.addView(txt(subtitle,13f,green,true))
        row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
        parent.addView(row)
    }

    private fun buildHome(p:LinearLayout) {
        buildHeader(p,"Delivery Decision","v0.2.3 • LIVE DASHBOARD")
        val statusCard=card()
        val sr=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        liveStatus=txt("",14f,green,true)
        sr.addView(liveStatus,LinearLayout.LayoutParams(0,-2,1f))
        liveTime=txt("00:00:00",17f,green,true); sr.addView(liveTime)
        statusCard.addView(sr)
        p.addView(statusCard); gap(p,10)

        val summary=card(); summary.addView(title("TODAY'S SUMMARY")); summary.addView(div())
        val metrics=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val a=miniMetric("EARNINGS","$0.00"); liveEarnings=a.second
        val b=miniMetric("MILES","0.0"); liveMiles=b.second
        val c=miniMetric("ACTIVE","00:00");
        metrics.addView(a.first,LinearLayout.LayoutParams(0,-2,1f));metrics.addView(b.first,LinearLayout.LayoutParams(0,-2,1f));metrics.addView(c.first,LinearLayout.LayoutParams(0,-2,1f))
        summary.addView(metrics)
        val dashBtn=neonButton(if(prefs.getBoolean("dash_active",false)) "END DASH" else "START DASH")
        dashBtn.setOnClickListener { if(prefs.getBoolean("dash_active",false)) startService(Intent(this,MileageService::class.java).setAction("STOP")) else startDash() }
        summary.addView(dashBtn,LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(8)})
        p.addView(summary); gap(p,10)

        val launch=card(); launch.addView(title("DRIVER APPS")); launch.addView(div())
        val lr=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val dd=outlineButton("OPEN\nDOORDASH",red); dd.setOnClickListener{launchDriverApp(listOf("com.doordash.driverapp"),"DoorDash")}
        val uber=outlineButton("OPEN\nUBER DRIVER",green); uber.setOnClickListener{launchDriverApp(listOf("com.ubercab.driver","com.ubercab"),"Uber Driver")}
        lr.addView(dd,LinearLayout.LayoutParams(0,dp(64),1f).apply{marginEnd=dp(5)});lr.addView(uber,LinearLayout.LayoutParams(0,dp(64),1f).apply{marginStart=dp(5)})
        launch.addView(lr);p.addView(launch);gap(p,10)

        val offer=card();
        val or=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val ot=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        ot.addView(title("OFFER READER"));ot.addView(txt("Analyze visible offers and show TAKE / CONSIDER / PASS.",12f,dim,false))
        or.addView(ot,LinearLayout.LayoutParams(0,-2,1f))
        val sw=Switch(this).apply{isChecked=isAccessibilityEnabled();setOnCheckedChangeListener{_,checked->if(checked!=isAccessibilityEnabled())startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}}
        or.addView(sw);offer.addView(or);offer.addView(div())
        val rules=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("MIN $/MI\n$${f2(prefs.getFloat("min_dpm",1.5f).toDouble())}","PREF $/MI\n$${f2(prefs.getFloat("preferred_dpm",2f).toDouble())}","MIN $/HR\n$${f2(prefs.getFloat("target_hour",25f).toDouble())}").forEach{rules.addView(txt(it,11f,Color.WHITE,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))}
        offer.addView(rules);p.addView(offer);gap(p,10)

        val auto=card();val ar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val at=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};at.addView(title("AUTO-STOP TIMER"));at.addView(txt("No offers or movement",12f,dim,false));ar.addView(at,LinearLayout.LayoutParams(0,-2,1f))
        liveAuto=txt("${prefs.getInt("auto_stop_min",30)} min",21f,green,true);ar.addView(liveAuto);auto.addView(ar);p.addView(auto)
        updateHomeLive(c.second)
    }

    private fun updateHomeLive(activeMetric:TextView?=null) {
        val active=prefs.getBoolean("dash_active",false); val start=prefs.getLong("dash_start",0L)
        val ms=if(active&&start>0)System.currentTimeMillis()-start else prefs.getLong("last_session_ms",0L)
        liveStatus?.text=if(active)"● DASH ACTIVE" else "○ DASH NOT ACTIVE"
        liveStatus?.setTextColor(if(active)green else dim)
        liveTime?.text=formatDuration(ms); liveEarnings?.text="$${f2(prefs.getFloat("today_earnings",0f).toDouble())}";liveMiles?.text="${f1(prefs.getFloat("today_miles",0f).toDouble())} mi"
        activeMetric?.text=formatDuration(ms).substring(0,5)
        liveAuto?.text="${prefs.getInt("auto_stop_min",30)} min"
    }

    private fun buildHistory(p:LinearLayout) {
        buildHeader(p,"History","PAST DASH SESSIONS")
        val filters=card(); val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("ALL","DOORDASH","UBER EATS").forEachIndexed{i,s->r.addView(if(i==0) neonButton(s) else darkButton(s),LinearLayout.LayoutParams(0,dp(44),1f).apply{if(i>0)marginStart=dp(6)})};filters.addView(r);p.addView(filters);gap(p,10)
        val raw=prefs.getString("dash_history","").orEmpty().lines().filter{it.isNotBlank()}.takeLast(30).reversed()
        if(raw.isEmpty()){val c=card();c.addView(txt("No completed dash sessions yet.",15f,dim,false));p.addView(c);return}
        val fmt=SimpleDateFormat("EEE, MMM d • h:mm a",Locale.US)
        raw.forEach{line->
            val x=line.split("|");if(x.size>=3){val st=x[0].toLongOrNull()?:0L;val en=x[1].toLongOrNull()?:st;val mi=x[2].toDoubleOrNull()?:0.0
                val c=card();val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};top.addView(txt(fmt.format(Date(st)),15f,Color.WHITE,true),LinearLayout.LayoutParams(0,-2,1f));top.addView(txt("${f1(mi)} mi",16f,green,true));c.addView(top);c.addView(txt("${formatDuration((en-st).coerceAtLeast(0L))} session • Delivery session",12f,dim,false));p.addView(c);gap(p,8)
            }
        }
    }

    private fun buildReports(p:LinearLayout) {
        buildHeader(p,"Reports","TRENDS & ANALYTICS")
        val period=card();val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};listOf("DAY","WEEK","MONTH","YEAR").forEachIndexed{i,s->r.addView(if(i==1)neonButton(s)else darkButton(s),LinearLayout.LayoutParams(0,dp(42),1f).apply{if(i>0)marginStart=dp(5)})};period.addView(r);p.addView(period);gap(p,10)
        val earnings=prefs.getFloat("today_earnings",0f).toDouble();val miles=prefs.getFloat("week_miles",0f).toDouble();val ms=prefs.getLong("last_session_ms",0L);val hr=if(ms>0)earnings/(ms/3600000.0) else 0.0;val dpm=if(miles>0)earnings/miles else 0.0
        val c=card();c.addView(title("CURRENT TOTALS"));c.addView(div());val g=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};listOf("EARNINGS\n$${f2(earnings)}","MILES\n${f1(miles)}","$/MILE\n$${f2(dpm)}").forEach{g.addView(txt(it,15f,green,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(64),1f))};c.addView(g);c.addView(txt("ACTIVE RATE   $${f2(hr)} / hr",15f,Color.WHITE,true).apply{gravity=Gravity.CENTER});p.addView(c);gap(p,10)
        val cost=card();cost.addView(title("COST ESTIMATES"));cost.addView(div());val mpg=prefs.getFloat("mpg",20f).toDouble().coerceAtLeast(1.0);val gas=prefs.getFloat("gas",3.99f).toDouble();cost.addView(valueRow("Estimated gas", "$${f2(miles/mpg*gas)}"));cost.addView(valueRow("Vehicle MPG",f1(mpg)));p.addView(cost)
    }

    private fun buildAccounts(p:LinearLayout) {
        buildHeader(p,"Accounts","APPS & CONNECTIONS")
        val apps=card();apps.addView(title("DRIVER APPS"));apps.addView(div());
        apps.addView(accountRow("DoorDash Dasher","Reader Mode Active","LAUNCH",red){launchDriverApp(listOf("com.doordash.driverapp"),"DoorDash")});apps.addView(div());apps.addView(accountRow("Uber Eats Driver","Not Connected","LAUNCH",green){launchDriverApp(listOf("com.ubercab.driver","com.ubercab"),"Uber Driver")});p.addView(apps);gap(p,10)
        val connected=card();connected.addView(title("CONNECTED ACCOUNTS"));connected.addView(div());connected.addView(accountRow("Uber","Official OAuth setup pending","CONNECT",green){AlertDialog.Builder(this).setTitle("Connect Uber").setMessage("The app is ready for official Uber OAuth, but we still need an approved Uber developer Client ID and permissions before real account syncing can work. Your Uber password will never be stored in Delivery Decision.").setPositiveButton("OK",null).show()});p.addView(connected);gap(p,10)
        val dd=card();dd.addView(title("DOORDASH ACCOUNT"));dd.addView(div());dd.addView(txt("Status: Reader Mode",15f,green,true));dd.addView(txt("Delivery Decision reads visible offers and keeps mileage/session records on this device. Direct account linking will only be added through an official DoorDash integration.",12f,dim,false));p.addView(dd)
    }

    private fun buildSettings(p:LinearLayout) {
        buildHeader(p,"Settings","PREFERENCES & TARGETS")
        val vehicle=card();vehicle.addView(title("VEHICLE & COSTS"));vehicle.addView(div());
        val mpg=editValueRow(vehicle,"Vehicle MPG",prefs.getFloat("mpg",20f).toString());val gas=editValueRow(vehicle,"Gas Price / Gallon",prefs.getFloat("gas",3.99f).toString());p.addView(vehicle);gap(p,10)
        val targets=card();targets.addView(title("EARNINGS TARGETS"));targets.addView(div());val min=editValueRow(targets,"Minimum $ / Mile",prefs.getFloat("min_dpm",1.5f).toString());val pref=editValueRow(targets,"Preferred $ / Mile",prefs.getFloat("preferred_dpm",2f).toString());val target=editValueRow(targets,"Minimum $ / Hour",prefs.getFloat("target_hour",25f).toString());p.addView(targets);gap(p,10)
        val auto=card();auto.addView(title("AUTO-STOP"));auto.addView(div());val stop=editValueRow(auto,"Inactive minutes (20–120)",prefs.getInt("auto_stop_min",30).toString());auto.addView(txt("Dash auto-ends only after no meaningful movement AND no offer activity for the selected time.",12f,dim,false));p.addView(auto);gap(p,10)
        val save=neonButton("SAVE SETTINGS");save.setOnClickListener{prefs.edit().putFloat("mpg",num(mpg,20f)).putFloat("gas",num(gas,3.99f)).putFloat("min_dpm",num(min,1.5f)).putFloat("preferred_dpm",num(pref,2f)).putFloat("target_hour",num(target,25f)).putInt("auto_stop_min",num(stop,30f).toInt().coerceIn(20,120)).apply();Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show()};p.addView(save,LinearLayout.LayoutParams(-1,dp(56)))
    }

    private fun buildTaxes(p:LinearLayout) {
        buildHeader(p,"Taxes","RECORDS & EXPORT")
        val ex=card();ex.addView(title("EXPORT RECORDS"));ex.addView(div());ex.addView(txt("Export your earnings and mileage records for recordkeeping or your tax preparer.",12f,dim,false));val csv=neonButton("EXPORT CSV");csv.setOnClickListener{exportTaxCsv()};ex.addView(csv,LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(8)});p.addView(ex);gap(p,10)
        val miles=prefs.getFloat("month_miles",0f).toDouble();val earn=prefs.getFloat("today_earnings",0f).toDouble();val log=card();log.addView(title("MILEAGE LOG"));log.addView(div());log.addView(valueRow("This month", "${f1(miles)} mi"));log.addView(valueRow("Today's business miles","${f1(prefs.getFloat("today_miles",0f).toDouble())} mi"));val correct=darkButton("CORRECT TODAY'S MILES");correct.setOnClickListener{correctMiles()};log.addView(correct,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(8)});p.addView(log);gap(p,10)
        val sum=card();sum.addView(title("RECORD SUMMARY"));sum.addView(div());sum.addView(valueRow("Today's earnings","$${f2(earn)}"));sum.addView(valueRow("This month miles","${f1(miles)}"));sum.addView(txt("Recordkeeping only — tax treatment and deductions depend on your situation.",11f,dim,false).apply{setPadding(0,dp(8),0,0)});p.addView(sum)
    }

    private fun rebuildNav() {
        nav.removeAllViews()
        listOf("Home" to "⌂","History" to "▣","Reports" to "▥","Accounts" to "♙","Settings" to "⚙","Taxes" to "▤").forEach{(name,ico)->
            val item=TextView(this).apply{ text="$ico\n$name";textSize=9.5f;gravity=Gravity.CENTER;setTextColor(if(name==currentTab)green else Color.LTGRAY);if(name==currentTab)setTypeface(typeface,Typeface.BOLD);setOnClickListener{showTab(name)} }
            nav.addView(item,LinearLayout.LayoutParams(0,-1,1f))
        }
    }

    private fun accountRow(name:String,status:String,button:String,color:Int,onClick:()->Unit):View {
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(5),0,dp(5))};val t=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};t.addView(txt(name,15f,Color.WHITE,true));t.addView(txt(status,12f,if(status.contains("Active"))green else dim,false));row.addView(t,LinearLayout.LayoutParams(0,-2,1f));val b=outlineButton(button,color);b.setOnClickListener{onClick()};row.addView(b,LinearLayout.LayoutParams(dp(95),dp(46)));return row
    }

    private fun editValueRow(parent:LinearLayout,label:String,value:String):EditText {
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};row.addView(txt(label,14f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f));val e=EditText(this).apply{setText(value);setTextColor(green);textSize=15f;gravity=Gravity.CENTER;inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;background=rounded(Color.rgb(5,12,5),Color.rgb(70,110,30),1,10f)};row.addView(e,LinearLayout.LayoutParams(dp(110),dp(46)));parent.addView(row);return e
    }

    private fun startDash() {
        val req=mutableListOf<String>();if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)req+=Manifest.permission.ACCESS_FINE_LOCATION;if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req+=Manifest.permission.POST_NOTIFICATIONS
        if(req.isNotEmpty()){requestPermissions(req.toTypedArray(),77);Toast.makeText(this,"Allow location, then tap START DASH again.",Toast.LENGTH_LONG).show()} else startForegroundService(Intent(this,MileageService::class.java).setAction("START"))
    }
    private fun launchDriverApp(packages:List<String>,label:String){for(pkg in packages){packageManager.getLaunchIntentForPackage(pkg)?.let{it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(it);return}};Toast.makeText(this,"$label is not installed on this phone.",Toast.LENGTH_LONG).show()}
    private fun correctMiles(){val input=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;setText(prefs.getFloat("today_miles",0f).toString());setSelectAllOnFocus(true)};AlertDialog.Builder(this).setTitle("Correct today's miles").setView(input).setPositiveButton("SAVE"){_,_->val nm=(input.text.toString().toFloatOrNull()?:return@setPositiveButton).coerceAtLeast(0f);val old=prefs.getFloat("today_miles",0f);val d=nm-old;prefs.edit().putFloat("today_miles",nm).putFloat("week_miles",(prefs.getFloat("week_miles",0f)+d).coerceAtLeast(0f)).putFloat("month_miles",(prefs.getFloat("month_miles",0f)+d).coerceAtLeast(0f)).apply()}.setNegativeButton("CANCEL",null).show()}
    private fun exportTaxCsv(){val name="DeliveryDecision_${SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())}.csv";startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(Intent.EXTRA_TITLE,name)},901)}
    @Deprecated("framework") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=901||resultCode!=RESULT_OK)return;val uri=data?.data?:return;val history=prefs.getString("dash_history","").orEmpty();val csv=buildString{appendLine("Date,Gross Earnings,Business Miles");appendLine("${SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())},${f2(prefs.getFloat("today_earnings",0f).toDouble())},${f1(prefs.getFloat("today_miles",0f).toDouble())}");appendLine();appendLine("Start,End,Miles");history.lines().filter{it.isNotBlank()}.forEach{line->val x=line.split("|");if(x.size>=3){val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);val st=x[0].toLongOrNull()?:0L;val en=x[1].toLongOrNull()?:0L;appendLine("${fmt.format(Date(st))},${fmt.format(Date(en))},${x[2]}")}}};runCatching{contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(csv)}}.onSuccess{Toast.makeText(this,"CSV saved",Toast.LENGTH_LONG).show()}.onFailure{Toast.makeText(this,"Could not save CSV",Toast.LENGTH_LONG).show()}}
    private fun isAccessibilityEnabled():Boolean{val enabled=Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?:return false;return enabled.contains("$packageName/.OfferReaderService",true)||enabled.contains("com.deliverydecision",true)}

    private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(12),dp(13),dp(12));background=rounded(Color.argb(235,2,10,5),green,1,15f)}
    private fun title(s:String)=txt(s,17f,Color.WHITE,true)
    private fun div()=View(this).apply{setBackgroundColor(Color.rgb(65,95,50));layoutParams=LinearLayout.LayoutParams(-1,1).apply{topMargin=dp(7);bottomMargin=dp(7)}}
    private fun miniMetric(label:String,value:String):Pair<LinearLayout,TextView>{val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(4),dp(3),dp(4))};b.addView(txt(label,10f,dim,true));val v=txt(value,19f,green,true).apply{gravity=Gravity.CENTER};b.addView(v);return Pair(b,v)}
    private fun valueRow(label:String,value:String):View{val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(txt(label,14f,Color.WHITE,false),LinearLayout.LayoutParams(0,-2,1f));r.addView(txt(value,15f,green,true));return r}
    private fun neonButton(s:String)=Button(this).apply{text=s;textSize=14f;setTextColor(Color.BLACK);setTypeface(typeface,Typeface.BOLD);background=rounded(green,green,0,12f)}
    private fun outlineButton(s:String,c:Int)=Button(this).apply{text=s;textSize=12f;setTextColor(c);setTypeface(typeface,Typeface.BOLD);background=rounded(Color.argb(235,2,7,3),c,2,11f)}
    private fun darkButton(s:String)=Button(this).apply{text=s;textSize=11f;setTextColor(Color.WHITE);background=rounded(Color.rgb(10,13,10),Color.rgb(80,90,80),1,10f)}
    private fun txt(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold)setTypeface(typeface,Typeface.BOLD)}
    private fun rounded(fill:Int,stroke:Int,strokeW:Int,r:Float)=GradientDrawable().apply{setColor(fill);cornerRadius=dp(r.toInt()).toFloat();if(strokeW>0)setStroke(dp(strokeW),stroke)}
    private fun gap(p:LinearLayout,h:Int)=p.addView(Space(this),LinearLayout.LayoutParams(1,dp(h)))
    private fun num(e:EditText,f:Float)=e.text.toString().toFloatOrNull()?:f
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun f1(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun f2(v:Double)=String.format(Locale.US,"%.2f",v)
    private fun formatDuration(ms:Long):String{val s=ms/1000;return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60)}
}
