package com.deliverydecision

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.os.*
import java.text.SimpleDateFormat
import java.util.*

class MileageService : Service(), LocationListener {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private lateinit var lm: LocationManager
    private var last: Location? = null
    private var lastMovement = 0L
    private val h = Handler(Looper.getMainLooper())
    private val autoStopMs = 90L * 60L * 1000L

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LocationManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when(intent?.action) {
            "STOP" -> stopDash(false)
            else -> startDash()
        }
        return START_STICKY
    }

    private fun startDash() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        resetPeriodsIfNeeded()
        prefs.edit()
            .putBoolean("dash_active", true)
            .putLong("dash_start", System.currentTimeMillis())
            .putBoolean("auto_stopped", false)
            .apply()
        lastMovement = System.currentTimeMillis()
        startForeground(77, notification("Tracking delivery miles"))
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2500L, 5f, this)
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 10f, this)
        } catch (_: Exception) {}
        h.removeCallbacks(checkIdle)
        h.postDelayed(checkIdle, 60000L)
    }

    private val checkIdle = object: Runnable {
        override fun run() {
            if (!prefs.getBoolean("dash_active",false)) return
            val now = System.currentTimeMillis()
            val lastOffer = prefs.getLong("last_offer_seen", now)
            if (now-lastMovement > autoStopMs && now-lastOffer > autoStopMs) stopDash(true)
            else h.postDelayed(this,60000L)
        }
    }

    private fun stopDash(auto:Boolean) {
        prefs.edit()
            .putBoolean("dash_active", false)
            .putBoolean("auto_stopped", auto)
            .putLong("dash_end", System.currentTimeMillis())
            .apply()
        try { lm.removeUpdates(this) } catch (_:Exception) {}
        h.removeCallbacksAndMessages(null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onLocationChanged(loc: Location) {
        if (!prefs.getBoolean("dash_active",false)) return
        if (loc.accuracy > 100f) return
        resetPeriodsIfNeeded()
        val prev=last
        if (prev != null) {
            val meters=prev.distanceTo(loc)
            val miles=meters/1609.344
            val dt=((loc.time-prev.time).coerceAtLeast(1L))/1000.0
            val mph=miles/(dt/3600.0)
            if (miles in 0.003..0.45 && mph < 100) {
                addMiles(miles.toFloat())
                lastMovement=System.currentTimeMillis()
            }
        }
        last=loc
    }

    private fun addMiles(m:Float) {
        prefs.edit()
            .putFloat("today_miles", prefs.getFloat("today_miles",0f)+m)
            .putFloat("week_miles", prefs.getFloat("week_miles",0f)+m)
            .putFloat("month_miles", prefs.getFloat("month_miles",0f)+m)
            .apply()
    }

    private fun resetPeriodsIfNeeded() {
        val now=Calendar.getInstance()
        val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(now.time)
        val month=SimpleDateFormat("yyyy-MM",Locale.US).format(now.time)
        val week="${now.get(Calendar.YEAR)}-${now.get(Calendar.WEEK_OF_YEAR)}"
        val e=prefs.edit()
        if (prefs.getString("day_key","")!=day) e.putString("day_key",day).putFloat("today_miles",0f)
        if (prefs.getString("week_key","")!=week) e.putString("week_key",week).putFloat("week_miles",0f)
        if (prefs.getString("month_key","")!=month) e.putString("month_key",month).putFloat("month_miles",0f)
        e.apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            val ch=NotificationChannel("mileage","Mileage tracking",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notification(text:String):Notification =
        Notification.Builder(this,"mileage")
            .setContentTitle("Delivery Decision")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

    override fun onBind(intent: Intent?) = null
}
