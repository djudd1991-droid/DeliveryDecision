package com.deliverydecision

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private lateinit var mpg: EditText
    private lateinit var gas: EditText
    private lateinit var minDpm: EditText
    private lateinit var preferredDpm: EditText
    private lateinit var targetHour: EditText
    private lateinit var mileageStatus: TextView
    private lateinit var mileageNumbers: TextView
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        ui.post(refresh)
    }

    private val refresh = object : Runnable {
        override fun run() {
            val active = prefs.getBoolean("dash_active", false)
            val today = prefs.getFloat("today_miles", 0f).toDouble()
            val week = prefs.getFloat("week_miles", 0f).toDouble()
            val month = prefs.getFloat("month_miles", 0f).toDouble()
            val gasPrice = prefs.getFloat("gas", 3.99f).toDouble()
            val mpgVal = prefs.getFloat("mpg", 20f).toDouble().coerceAtLeast(1.0)
            val start = prefs.getLong("dash_start", 0L)
            val elapsed = if (active && start > 0) System.currentTimeMillis() - start else 0L
            mileageStatus.text = if (active) "● DASH ACTIVE   ${formatDuration(elapsed)}" else "○ DASH NOT ACTIVE"
            mileageStatus.setTextColor(if (active) Color.rgb(145,255,0) else Color.LTGRAY)
            mileageNumbers.text =
                "TODAY   ${fmt(today)} mi   •   Gas ~$${fmt2(today / mpgVal * gasPrice)}\n" +
                "THIS WEEK   ${fmt(week)} mi   •   THIS MONTH   ${fmt(month)} mi"
            ui.postDelayed(this, 1000)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(3,8,3)) }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 28, 30, 50)
        }
        scroll.addView(main)
        setContentView(scroll)

        main.addView(label("Delivery Decision v0.2", 28f, Color.WHITE, true))
        main.addView(label("TAKE • CONSIDER • PASS", 17f, Color.rgb(145,255,0), true))
        spacer(main, 20)

        val ruleCard = card()
        ruleCard.addView(label("YOUR RULES", 22f, Color.rgb(145,255,0), true))
        mpg = settingRow(ruleCard, "MPG", prefs.getFloat("mpg",20f).toString())
        gas = settingRow(ruleCard, "Gas Price ($/gal)", prefs.getFloat("gas",3.99f).toString())
        minDpm = settingRow(ruleCard, "Minimum $/mile", prefs.getFloat("min_dpm",1.50f).toString())
        preferredDpm = settingRow(ruleCard, "Preferred $/mile", prefs.getFloat("preferred_dpm",2.00f).toString())
        targetHour = settingRow(ruleCard, "Target $/hour", prefs.getFloat("target_hour",25f).toString())

        val save = neonButton("SAVE SETTINGS")
        save.setOnClickListener {
            prefs.edit()
                .putFloat("mpg", value(mpg,20f))
                .putFloat("gas", value(gas,3.99f))
                .putFloat("min_dpm", value(minDpm,1.5f))
                .putFloat("preferred_dpm", value(preferredDpm,2f))
                .putFloat("target_hour", value(targetHour,25f))
                .apply()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }
        ruleCard.addView(save)
        main.addView(ruleCard)
        spacer(main, 18)

        val milesCard = card()
        milesCard.addView(label("MILEAGE TRACKER", 22f, Color.rgb(145,255,0), true))
        mileageStatus = label("", 16f, Color.LTGRAY, true)
        mileageNumbers = label("", 20f, Color.WHITE, true)
        milesCard.addView(mileageStatus)
        milesCard.addView(mileageNumbers)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = neonButton("START DASH")
        val end = darkButton("END DASH")
        row.addView(start, LinearLayout.LayoutParams(0, 120, 1f))
        row.addView(end, LinearLayout.LayoutParams(0, 120, 1f))
        milesCard.addView(row)

        val correct = darkButton("CORRECT TODAY'S MILES")
        correct.setOnClickListener { showMileageCorrection() }
        milesCard.addView(correct)
        milesCard.addView(label(
            "Auto-stop protection ends tracking after 90 minutes with no movement and no DoorDash/Uber offer activity.",
            14f, Color.LTGRAY, false
        ))

        start.setOnClickListener { startDash() }
        end.setOnClickListener { startService(Intent(this, MileageService::class.java).setAction("STOP")) }
        main.addView(milesCard)
        spacer(main, 18)

        val offerCard = card()
        offerCard.addView(label("OFFER READER", 22f, Color.rgb(145,255,0), true))
        offerCard.addView(label(
            "Reads visible DoorDash/Uber offer text and shows a stable overlay with payout, miles, $/mile, estimated fuel cost, and TAKE / CONSIDER / PASS.",
            15f, Color.LTGRAY, false
        ))
        val enable = neonButton("ENABLE OFFER READER")
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        offerCard.addView(enable)
        main.addView(offerCard)
    }

    private fun startDash() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.POST_NOTIFICATIONS

        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 88)
            Toast.makeText(this, "Allow location, then tap START DASH again.", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, MileageService::class.java).setAction("START"))
    }

    private fun showMileageCorrection() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(fmt(prefs.getFloat("today_miles",0f).toDouble()))
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Correct today's miles")
            .setMessage("Enter the correct total delivery miles for today.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val newMiles = input.text.toString().toFloatOrNull() ?: return@setPositiveButton
                val old = prefs.getFloat("today_miles",0f)
                val delta = newMiles - old
                prefs.edit()
                    .putFloat("today_miles", newMiles.coerceAtLeast(0f))
                    .putFloat("week_miles", (prefs.getFloat("week_miles",0f)+delta).coerceAtLeast(0f))
                    .putFloat("month_miles", (prefs.getFloat("month_miles",0f)+delta).coerceAtLeast(0f))
                    .apply()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24,22,24,22)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(5,8,5))
            setStroke(2, Color.rgb(145,255,0))
            cornerRadius = 30f
        }
    }

    private fun settingRow(parent: LinearLayout, title: String, initial: String): EditText {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0,14,0,14)
        }
        row.addView(label(title, 17f, Color.WHITE, true), LinearLayout.LayoutParams(0,-2,1f))
        val edit = EditText(this).apply {
            setText(initial)
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(8,10,8))
                setStroke(2, Color.rgb(145,255,0))
                cornerRadius = 20f
            }
        }
        row.addView(edit, LinearLayout.LayoutParams(190, 95))
        parent.addView(row)
        return edit
    }

    private fun neonButton(text: String): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        setTextColor(Color.BLACK)
        setTypeface(typeface, Typeface.BOLD)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(145,255,0))
            cornerRadius = 24f
        }
    }

    private fun darkButton(text: String): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(12,12,12))
            setStroke(2, Color.rgb(145,255,0))
            cornerRadius = 24f
        }
    }

    private fun label(s:String, size:Float, color:Int, bold:Boolean) = TextView(this).apply {
        text=s; textSize=size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0,5,0,5)
    }
    private fun spacer(parent:LinearLayout,h:Int) = parent.addView(Space(this), LinearLayout.LayoutParams(1,h))
    private fun value(e:EditText, fallback:Float) = e.text.toString().toFloatOrNull() ?: fallback
    private fun fmt(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun fmt2(v:Double)=String.format(Locale.US,"%.2f",v)
    private fun formatDuration(ms:Long):String {
        val s=ms/1000
        return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60)
    }
}
