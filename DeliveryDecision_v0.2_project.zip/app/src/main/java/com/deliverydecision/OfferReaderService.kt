package com.deliverydecision

import android.accessibilityservice.AccessibilityService
import android.graphics.*
import android.os.*
import android.view.*
import android.view.accessibility.*
import android.widget.TextView
import java.util.*
import java.util.regex.Pattern
import kotlin.math.max

data class Offer(val pay:Double,val miles:Double)

object OfferParser {
    private val money=Pattern.compile("\\$(\\d+(?:\\.\\d{1,2})?)")
    private val miles=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(?:mi|miles)",Pattern.CASE_INSENSITIVE)
    fun parse(text:String):Offer? {
        val m=money.matcher(text); val d=miles.matcher(text)
        if(!m.find()||!d.find()) return null
        val pay=m.group(1)?.toDoubleOrNull()?:return null
        val dist=d.group(1)?.toDoubleOrNull()?:return null
        if(pay<=0||dist<=0||pay>500||dist>200) return null
        return Offer(pay,dist)
    }
}

class OfferReaderService:AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("dd", MODE_PRIVATE) }
    private var overlay:TextView?=null
    private var shownKey=""
    private val handler=Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event:AccessibilityEvent?) {
        val pkg=event?.packageName?.toString()?:return
        if(pkg==packageName) return

        val supported = pkg=="com.doordash.driverapp" || pkg=="com.ubercab.driver" || pkg=="com.ubercab"
        if(!supported) {
            hide()
            shownKey=""
            return
        }

        val root=rootInActiveWindow?:return
        val text=collect(root)
        val offer=OfferParser.parse(text)
        if(offer==null) {
            if(shownKey.isNotEmpty()) { hide(); shownKey="" }
            return
        }

        prefs.edit().putLong("last_offer_seen",System.currentTimeMillis()).apply()
        val key="$pkg|${offer.pay}|${offer.miles}"
        if(key==shownKey && overlay!=null) return
        shownKey=key
        show(pkg,offer)
    }

    private fun collect(node:AccessibilityNodeInfo):String {
        val out=StringBuilder()
        fun walk(n:AccessibilityNodeInfo?) {
            if(n==null)return
            n.text?.let{out.append(it).append(" ")}
            n.contentDescription?.let{out.append(it).append(" ")}
            for(i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(node); return out.toString()
    }

    private fun show(pkg:String,o:Offer) {
        val mpg=prefs.getFloat("mpg",20f).toDouble().coerceAtLeast(1.0)
        val gas=prefs.getFloat("gas",3.99f).toDouble()
        val min=prefs.getFloat("min_dpm",1.5f).toDouble()
        val pref=prefs.getFloat("preferred_dpm",2f).toDouble()
        val dpm=o.pay/max(o.miles,.1)
        val fuel=o.miles/mpg*gas
        val net=o.pay-fuel
        val decision=when {
            dpm>=pref -> "TAKE"
            dpm>=min -> "CONSIDER"
            else -> "PASS"
        }
        val app=if(pkg.contains("doordash"))"DoorDash" else "Uber Eats"
        val msg="● $decision   $app\n$${fmt(o.pay)} • ${fmt(o.miles)} mi • $${fmt(dpm)}/mi\nFuel ~$${fmt(fuel)}  •  After fuel ~$${fmt(net)}"

        handler.post {
            if(overlay==null) {
                overlay=TextView(this).apply {
                    textSize=15f
                    setTextColor(Color.WHITE)
                    setPadding(20,14,20,14)
                }
                val lp=WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y=115
                }
                getSystemService(WindowManager::class.java).addView(overlay,lp)
            }
            overlay?.background=android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(245,5,8,5))
                setStroke(3,when(decision){
                    "TAKE"->Color.rgb(145,255,0)
                    "PASS"->Color.rgb(255,65,54)
                    else->Color.rgb(255,210,0)
                })
                cornerRadius=22f
            }
            overlay?.text=msg
        }
    }

    private fun hide() {
        handler.post {
            overlay?.let{runCatching{getSystemService(WindowManager::class.java).removeView(it)}}
            overlay=null
        }
    }
    private fun fmt(v:Double)=String.format(Locale.US,"%.2f",v)
    override fun onInterrupt()=Unit
}
